"""
Hidden tests for Java Fundamentals Consolidation assessment
"""
import unittest
import subprocess
import os
import sys
import io
import re
import xml.etree.ElementTree as ET
from pathlib import Path
import tempfile
import shutil
import glob

# Define color codes for output
class Colors:
    GREEN = '\033[92m'    # Success messages
    RED = '\033[91m'      # Error/failure messages
    YELLOW = '\033[93m'   # Warning messages
    CYAN = '\033[96m'     # Information messages
    BLUE = '\033[94m'     # Neutral status messages
    BOLD = '\033[1m'      # Bold text
    END = '\033[0m'       # Reset colors

# Find project root (directory containing pom.xml)
def find_project_root():
    """Find the project root by looking for pom.xml"""
    # Start with the directory containing this script
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Try different paths to find pom.xml
    possible_roots = [
        script_dir,  # Current directory
        os.path.dirname(script_dir),  # Parent directory
        os.path.dirname(os.path.dirname(script_dir)),  # Grandparent directory
        os.getcwd(),  # Current working directory
    ]

    for path in possible_roots:
        if os.path.exists(os.path.join(path, "pom.xml")):
            return path

    # If not found in common locations, start a broader search
    # from the directory containing this script
    current_dir = script_dir

    # Go up at most 4 levels to find pom.xml
    for _ in range(5):
        if os.path.exists(os.path.join(current_dir, "pom.xml")):
            return current_dir
        parent_dir = os.path.dirname(current_dir)
        if parent_dir == current_dir:  # Reached root of filesystem
            break
        current_dir = parent_dir

    # If still not found, default to the parent of script directory
    return os.path.dirname(script_dir)

# Configuration - with dynamic path detection
PROJECT_ROOT = find_project_root()
SRC_DIR = os.path.join(PROJECT_ROOT, "src", "main", "java", "wethinkco", "de")
TEST_DIR = os.path.join(PROJECT_ROOT, "src", "test", "java", "wethinkco", "de")
STUDENT_FILE = os.path.join(SRC_DIR, "Consolidation.java")
STUDENT_TEST_FILE = os.path.join(TEST_DIR, "ConsolidationTest.java")
MIN_STUDENT_TESTS = 6  # One for each required function (excluding Pascal's Triangle)

# Scoring configuration
implementation_score = 0
test_score = 0
implementation_total = 6  # Total reflects implementation of 6 functions
test_total = 1  # One point for having sufficient tests
total = implementation_total + test_total

# Feedback messages
feedback_messages = []

def color_print(text, color=None, bold=False):
    """Print colored text if supported"""
    try:
        if color:
            prefix = Colors.BOLD if bold else ""
            print(f"{prefix}{color}{text}{Colors.END}")
        else:
            print(text)
    except:
        # Fallback if color printing fails
        print(text)

# Suppress output during test execution
class SuppressOutput:
    def __enter__(self):
        self._original_stdout = sys.stdout
        sys.stdout = io.StringIO()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout = self._original_stdout

def check_file_exists(filepath, description):
    """Check if file exists and provide feedback if not"""
    if not os.path.exists(filepath):
        color_print(f"❌ Required file '{filepath}' was not found.", Colors.RED)
        print(f"Looking for {description} at: {filepath}")
        print(f"Project root detected at: {PROJECT_ROOT}")
        return False
    return True

def compile_student_code():
    """Compile student code using Maven and return if successful"""
    try:
        with SuppressOutput():
            result = subprocess.run(
                ["mvn", "compile", "-q"],
                cwd=PROJECT_ROOT,
                check=False,  # Don't raise exception on error
                capture_output=True,
                text=True
            )

        if result.returncode != 0:
            error_msg = result.stderr.strip() if result.stderr else "Unknown compilation error"
            feedback_messages.append(f"❌ Failed to compile student code: {error_msg}. Check for syntax errors.")
            return False

        return True
    except Exception as e:
        feedback_messages.append(f"❌ Error during compilation: {str(e)}.")
        return False

def check_implementation_file():
    """Check if the implementation file has all required methods"""
    try:
        with open(STUDENT_FILE, 'r') as f:
            content = f.read()

        # Check for each required method
        method_patterns = [
            r'(?:public\s+)?(?:static\s+)?List<String>\s+fizzBuzz\s*\(\s*int\s+\w+\s*\)',
            r'(?:public\s+)?(?:static\s+)?String\s+fibonacciSequence\s*\(\s*int\s+\w+\s*\)',
            r'(?:public\s+)?(?:static\s+)?String\s+calculate\s*\(\s*int\s+\w+\s*,\s*int\s+\w+\s*,\s*String\s+\w+\s*\)',
            r'(?:public\s+)?(?:static\s+)?String\s+drawTriangle\s*\(\s*int\s+\w+\s*\)',
            r'(?:public\s+)?(?:static\s+)?boolean\s+isPalindrome\s*\(\s*String\s+\w+\s*\)',
            r'(?:public\s+)?(?:static\s+)?long\s+factorial\s*\(\s*int\s+\w+\s*\)'
        ]

        missing_methods = []
        for i, pattern in enumerate(method_patterns):
            if not re.search(pattern, content):
                method_names = ["fizzBuzz", "fibonacciSequence", "calculate", "drawTriangle",
                                "isPalindrome", "factorial"]
                missing_methods.append(method_names[i])

        if missing_methods:
            feedback_messages.append(f"❌ Missing implementation for methods: {', '.join(missing_methods)}")
            return False
        return True
    except Exception as e:
        feedback_messages.append(f"❌ Error checking implementation file: {str(e)}.")
        return False

def run_student_tests():
    """Run student tests using Maven Surefire and return results"""
    try:
        with SuppressOutput():
            result = subprocess.run(
                ["mvn", "test", "-q"],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True
            )

        # Parse the Surefire reports
        surefire_dir = os.path.join(PROJECT_ROOT, "target", "surefire-reports")
        if not os.path.exists(surefire_dir):
            feedback_messages.append("❌ No test reports found. Tests may have failed to run.")
            return False, 0, []

        # Find the ConsolidationTest report
        xml_reports = glob.glob(os.path.join(surefire_dir, "*ConsolidationTest.xml"))
        if not xml_reports:
            feedback_messages.append("❌ No test report found for ConsolidationTest.")
            return False, 0, []

        # Parse the XML report
        tree = ET.parse(xml_reports[0])
        root = tree.getroot()

        tests_run = int(root.attrib.get('tests', 0))
        failures = int(root.attrib.get('failures', 0))
        errors = int(root.attrib.get('errors', 0))
        skipped = int(root.attrib.get('skipped', 0))

        # Get test method names
        test_methods = []
        for testcase in root.findall('.//testcase'):
            test_methods.append(testcase.attrib.get('name'))

        return (failures == 0 and errors == 0), tests_run, test_methods
    except Exception as e:
        feedback_messages.append(f"❌ Error running student tests: {str(e)}.")
        return False, 0, []

def count_student_test_methods():
    """Count the number of test methods in the student's test file"""
    try:
        with open(STUDENT_TEST_FILE, 'r') as f:
            content = f.read()

        # Count methods that start with @Test annotation
        test_count = len(re.findall(r'@Test\s+(?:public\s+)?void\s+test\w+', content))
        return test_count
    except Exception as e:
        feedback_messages.append(f"❌ Error counting test methods: {str(e)}.")
        return 0

def validate_with_reference_solutions():
    """Direct validation against reference solutions"""
    global implementation_score

    # Run tests
    try:
        # Construct classpath
        with SuppressOutput():
            subprocess.run(
                ["mvn", "clean", "compile", "-q"],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True
            )

        # Run all tests first
        with SuppressOutput():
            result = subprocess.run(
                ["mvn", "test", "-q"],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True
            )

        # List of method names
        methods = ["fizzBuzz", "fibonacciSequence", "calculate", "drawTriangle", "isPalindrome", "factorial"]

        if result.returncode == 0:
            # All tests pass, so all functions must be correct
            implementation_score = implementation_total  # All functions are correct
            for method in methods:
                feedback_messages.append(f"✅ {method} method works correctly for all test cases")
        else:
            # Some tests failed, run individual tests
            for method in methods:
                test_method = "test" + method[0].upper() + method[1:]
                with SuppressOutput():
                    method_result = subprocess.run(
                        ["mvn", "-Dtest=ConsolidationTest#" + test_method, "test", "-q"],
                        cwd=PROJECT_ROOT,
                        capture_output=True,
                        text=True
                    )

                if method_result.returncode == 0:
                    implementation_score += 1
                    feedback_messages.append(f"✅ {method} method works correctly for all test cases")
                else:
                    feedback_messages.append(f"❌ {method}: Test failed. Check your implementation.")

    except Exception as e:
        feedback_messages.append(f"❌ Error validating solutions: {str(e)}.")

def test_student_tests():
    """Test if the student has implemented tests for all functions"""
    global test_score

    test_count = count_student_test_methods()

    if test_count >= MIN_STUDENT_TESTS:
        test_score = 1  # Award 1 point for having sufficient tests
        feedback_messages.append(f"✅ You've provided {test_count} test methods (minimum required: {MIN_STUDENT_TESTS})")

        # Check if their tests pass
        tests_pass, tests_run, test_methods = run_student_tests()

        if tests_pass:
            feedback_messages.append("✅ All your tests are passing. Good job!")

            # Check if they have a test for each required function
            function_names = ["fizzBuzz", "fibonacciSequence", "calculate", "drawTriangle",
                              "isPalindrome", "factorial"]

            # Convert to lowercase for case-insensitive comparison
            test_methods_lower = [m.lower() for m in test_methods]
            missing_tests = []

            for func in function_names:
                found = False
                for test in test_methods_lower:
                    if func.lower() in test:
                        found = True
                        break
                if not found:
                    missing_tests.append(func)

            if missing_tests:
                feedback_messages.append(f"⚠️ You're missing tests for: {', '.join(missing_tests)}. Make sure to test all required functions.")
            else:
                feedback_messages.append("✅ You have tests for all required functions.")
        else:
            feedback_messages.append("⚠️ Some of your tests are failing. Make sure your tests match your implementation.")

    else:
        feedback_messages.append(f"📉 You need a minimum of {MIN_STUDENT_TESTS} test methods (one for each required function). You currently have {test_count}.")

if __name__ == "__main__":
    # Display initial message
    color_print("🚀 Running hidden tests for Java Fundamentals Consolidation...", Colors.CYAN, True)

    # Print detected paths for debugging
    print(f"Project root detected at: {PROJECT_ROOT}")
    print(f"Looking for Consolidation.java at: {STUDENT_FILE}")
    print(f"Looking for ConsolidationTest.java at: {STUDENT_TEST_FILE}")

    # Check if required files exist
    if not check_file_exists(STUDENT_FILE, "Consolidation.java") or not check_file_exists(STUDENT_TEST_FILE, "ConsolidationTest.java"):
        sys.exit(1)

    # Check implementation file
    if not check_implementation_file():
        color_print("❌ Your implementation file is missing required methods.", Colors.RED)

    # Compile the code
    if not compile_student_code():
        color_print("❌ Failed to compile. Please fix compilation errors before running tests.", Colors.RED)
        sys.exit(1)

    # Validate using reference solutions
    validate_with_reference_solutions()

    # Run the student tests check
    test_student_tests()

    # Calculate total score and percentage
    total_score = implementation_score + test_score
    percentage = (total_score / total) * 100 if total > 0 else 0

    # Determine color based on score
    if percentage >= 80:
        result_color = Colors.GREEN
    elif percentage >= 60:
        result_color = Colors.YELLOW
    else:
        result_color = Colors.RED

    # Display results
    print("\n" + "=" * 50)
    color_print("       ASSESSMENT RESULTS       ", Colors.CYAN, True)
    print("=" * 50 + "\n")

    print("📋 Feedback:")
    for msg in feedback_messages:
        if "✅" in msg:
            color_print(msg, Colors.GREEN)
        elif "⚠️" in msg:
            color_print(msg, Colors.YELLOW)
        else:
            color_print(msg, Colors.RED)

    print("\n" + "-" * 50)
    color_print(f"Implementation Score: {implementation_score}/{implementation_total}", Colors.BLUE)
    color_print(f"Test Coverage Score: {test_score}/{test_total}", Colors.BLUE)
    color_print(f"🏁 Final Score: {total_score}/{total} ({percentage:.1f}%)", result_color, True)

    if total_score == total:
        color_print("🎉 Excellent work! You've completed all the requirements for this assessment.", Colors.GREEN)
    elif total_score >= 5:
        color_print("👍 You're making good progress. Review the feedback above to complete the remaining requirements.", Colors.YELLOW)
    else:
        color_print("🛠️ You have several requirements to address. Focus on implementing the missing functions and improving your tests.", Colors.RED)
    print("-" * 50)