"""
Hidden tests for consolidation assessment
"""
import unittest
import importlib.util
import os
import sys
import io
import math

# Configuration
STUDENT_FILE = "consolidation.py"

score = 0
total = 7  # Total reflects all 7 functions

# Color output support
class Colors:
    GREEN = '\033[92m'    
    RED = '\033[91m'      
    YELLOW = '\033[93m'   
    CYAN = '\033[96m'     
    BOLD = '\033[1m'      
    END = '\033[0m'       

def color_print(text, color=None, bold=False):
    """Print colored text if supported"""
    try:
        if color:
            prefix = Colors.BOLD if bold else ""
            print(f"{prefix}{color}{text}{Colors.END}")
        else:
            print(text)
    except:
        print(text)

# Load student implementation
def load_student_module():
    if not os.path.exists(STUDENT_FILE):
        color_print(f"❌ Required file '{STUDENT_FILE}' was not found.", Colors.RED)
        color_print(f"Make sure you have a file named '{STUDENT_FILE}' in your current directory.", Colors.YELLOW)
        return None
    
    try:
        spec = importlib.util.spec_from_file_location("consolidation", STUDENT_FILE)
        student_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(student_module)
        return student_module
    except Exception as e:
        color_print(f"❌ Error loading {STUDENT_FILE}: {str(e)}", Colors.RED)
        color_print("Make sure your consolidation.py file has no syntax errors.", Colors.YELLOW)
        return None

student = load_student_module()
if student is None:
    sys.exit(1)

# Feedback lists
feedback_messages = []

class TestConsolidation(unittest.TestCase):
    
    def test_fibonacci(self):
        global score
        if not hasattr(student, 'fibonacci') or not callable(getattr(student, 'fibonacci', None)):
            feedback_messages.append("🤔 Could not find a function named 'fibonacci'. Make sure you've implemented this function in consolidation.py.")
            self.fail("Missing or invalid 'fibonacci' function.")
            return

        # Test cases
        test_cases = [
            (0, []),
            (1, [0]),
            (2, [0, 1]),
            (5, [0, 1, 1, 2, 3]),
            (8, [0, 1, 1, 2, 3, 5, 8, 13]),
            (10, [0, 1, 1, 2, 3, 5, 8, 13, 21, 34])
        ]
        
        try:
            for n, expected in test_cases:
                result = student.fibonacci(n)
                self.assertEqual(result, expected, f"fibonacci({n}) returned {result}, expected {expected}")
            
            score += 1
            feedback_messages.append("✅ fibonacci function works correctly for all test cases")
        except AssertionError as e:
            feedback_messages.append(f"❌ fibonacci() doesn't produce the expected sequence. Remember: start with 0, 1, then each number is sum of previous two. For n=0 return empty list, n=1 return [0].")
            raise
        except Exception as e:
            feedback_messages.append(f"⚠️ fibonacci() raised an error: {type(e).__name__}. Check your loop logic and list handling.")
            raise

    def test_factorial(self):
        global score
        if not hasattr(student, 'factorial') or not callable(getattr(student, 'factorial', None)):
            feedback_messages.append("🤔 Could not find a function named 'factorial'. Make sure you've implemented this function in consolidation.py.")
            self.fail("Missing or invalid 'factorial' function.")
            return

        # Test cases
        test_cases = [
            (0, 1),   # 0! = 1 by definition
            (1, 1),   # 1! = 1
            (2, 2),   # 2! = 2
            (3, 6),   # 3! = 6
            (4, 24),  # 4! = 24
            (5, 120), # 5! = 120
            (6, 720), # 6! = 720
            (7, 5040) # 7! = 5040
        ]
        
        try:
            for n, expected in test_cases:
                result = student.factorial(n)
                self.assertEqual(result, expected, f"factorial({n}) returned {result}, expected {expected}")
            
            # Test negative number returns empty string
            negative_result = student.factorial(-1)
            self.assertEqual(negative_result, "", "factorial(-1) should return empty string")
            
            negative_result2 = student.factorial(-5)
            self.assertEqual(negative_result2, "", "factorial(-5) should return empty string")
            
            score += 1
            feedback_messages.append("✅ factorial function works correctly for all test cases including negative numbers")
        except AssertionError as e:
            feedback_messages.append(f"❌ factorial() doesn't produce the expected result. Remember: n! = n * (n-1) * ... * 1, and 0! = 1. For negative numbers, return empty string.")
            raise
        except Exception as e:
            feedback_messages.append(f"⚠️ factorial() raised an error: {type(e).__name__}. Check your multiplication logic and edge cases.")
            raise

    def test_count_letters_and_punctuation(self):
        global score
        if not hasattr(student, 'count_letters_and_punctuation') or not callable(getattr(student, 'count_letters_and_punctuation', None)):
            feedback_messages.append("🤔 Could not find a function named 'count_letters_and_punctuation'. Make sure you've implemented this function in consolidation.py.")
            self.fail("Missing or invalid 'count_letters_and_punctuation' function.")
            return

        # Test cases
        test_cases = [
            ("Hello, World!", {'!': 1, ',': 1, 'd': 1, 'e': 1, 'h': 1, 'l': 3, 'o': 2, 'r': 1, 'w': 1}),
            ("", {}),  # Empty string
            ("aaa", {'a': 3}),  # Single character repeated
            ("A!B@C#", {'!': 1, '#': 1, '@': 1, 'a': 1, 'b': 1, 'c': 1}),  # Mixed case and punctuation
            ("Python is awesome!", {'!': 1, 'a': 1, 'e': 2, 'h': 1, 'i': 1, 'm': 1, 'n': 2, 'o': 2, 'p': 1, 'r': 1, 's': 3, 't': 1, 'w': 1, 'y': 1}),
            ("123 abc!", {'!': 1, 'a': 1, 'b': 1, 'c': 1})  # Numbers should be ignored, spaces ignored
        ]
        
        try:
            for sentence, expected in test_cases:
                result = student.count_letters_and_punctuation(sentence)
                # Compare dictionaries by content, not order
                self.assertEqual(len(result), len(expected), f"count_letters_and_punctuation('{sentence}') returned dictionary with {len(result)} items, expected {len(expected)}")
                for key, value in expected.items():
                    self.assertIn(key, result, f"count_letters_and_punctuation('{sentence}') missing key '{key}'")
                    self.assertEqual(result[key], value, f"count_letters_and_punctuation('{sentence}') key '{key}' has value {result[key]}, expected {value}")
                # Ensure no extra keys
                for key in result:
                    self.assertIn(key, expected, f"count_letters_and_punctuation('{sentence}') has unexpected key '{key}'")
            
            score += 1
            feedback_messages.append("✅ count_letters_and_punctuation function works correctly for all test cases")
        except AssertionError as e:
            feedback_messages.append(f"❌ count_letters_and_punctuation() doesn't produce the expected result. Remember: count letters and punctuation (ignore numbers), convert to lowercase, sort alphabetically.")
            raise
        except Exception as e:
            feedback_messages.append(f"⚠️ count_letters_and_punctuation() raised an error: {type(e).__name__}. Check your character filtering and sorting logic.")
            raise

    def test_count_perfect_squares_in_list(self):
        global score
        if not hasattr(student, 'count_perfect_squares_in_list') or not callable(getattr(student, 'count_perfect_squares_in_list', None)):
            feedback_messages.append("🤔 Could not find a function named 'count_perfect_squares_in_list'. Make sure you've implemented this function in consolidation.py.")
            self.fail("Missing or invalid 'count_perfect_squares_in_list' function.")
            return

        # Test cases
        test_cases = [
            ([4, 9, 16, 17], 3),  # 4, 9, 16 are perfect squares
            ([1, 4, 9], 3),       # All are perfect squares
            ([2, 3, 5, 7], 0),    # No perfect squares
            ([], 0),              # Empty list
            ([0], 1),             # 0 is a perfect square (0*0 = 0)
            ([1], 1),             # 1 is a perfect square (1*1 = 1)
            ([25, 36, 49, 50], 3), # 25, 36, 49 are perfect squares
            ([100, 121, 144, 150], 3), # 100, 121, 144 are perfect squares
            ([-4, 4, 9], 2),      # Negative numbers are not perfect squares
            ([16, 16, 25, 25], 4) # Duplicates count separately
        ]
        
        try:
            for numbers, expected in test_cases:
                result = student.count_perfect_squares_in_list(numbers)
                self.assertEqual(result, expected, f"count_perfect_squares_in_list({numbers}) returned {result}, expected {expected}")
            
            score += 1
            feedback_messages.append("✅ count_perfect_squares_in_list function works correctly for all test cases")
        except AssertionError as e:
            feedback_messages.append(f"❌ count_perfect_squares_in_list() doesn't produce the expected count. Remember: perfect square = integer whose square root is also an integer. Include 0 and 1.")
            raise
        except Exception as e:
            feedback_messages.append(f"⚠️ count_perfect_squares_in_list() raised an error: {type(e).__name__}. Check your square root calculation and validation logic.")
            raise

    def test_draw_triangle_prime(self):
        global score
        if not hasattr(student, 'draw_triangle_prime') or not callable(getattr(student, 'draw_triangle_prime', None)):
            feedback_messages.append("🤔 Could not find a function named 'draw_triangle_prime'. Make sure you've implemented this function in consolidation.py.")
            self.fail("Missing or invalid 'draw_triangle_prime' function.")
            return

        # Test cases with expected outputs
        test_cases = [
            (1, "2"),
            (2, "2\n3 5"),
            (3, "2\n3 5\n7 11 13"),
            (4, "2\n3 5\n7 11 13\n17 19 23 29")
        ]
        
        try:
            for height, expected in test_cases:
                # Capture printed output
                captured_output = io.StringIO()
                original_stdout = sys.stdout
                sys.stdout = captured_output
                
                student.draw_triangle_prime(height)
                
                sys.stdout = original_stdout
                result = captured_output.getvalue().strip()
                
                self.assertEqual(result, expected, f"draw_triangle_prime({height}) printed '{result}', expected '{expected}'")
            
            score += 1
            feedback_messages.append("✅ draw_triangle_prime function works correctly for all test cases")
        except AssertionError as e:
            feedback_messages.append(f"❌ draw_triangle_prime() doesn't produce the expected output. Remember: each row i should contain i consecutive prime numbers, starting from 2.")
            raise
        except Exception as e:
            feedback_messages.append(f"⚠️ draw_triangle_prime() raised an error: {type(e).__name__}. Check your prime number generation and triangle formatting logic.")
            raise

    def test_matrix_multiply(self):
        global score
        if not hasattr(student, 'matrix_multiply') or not callable(getattr(student, 'matrix_multiply', None)):
            feedback_messages.append("🤔 Could not find a function named 'matrix_multiply'. Make sure you've implemented this function in consolidation.py.")
            self.fail("Missing or invalid 'matrix_multiply' function.")
            return

        # Test cases
        test_cases = [
            # Basic 2x3 * 3x2 = 2x2
            (
                [[1, 2, 3], [4, 5, 6]],
                [[7, 8], [9, 10], [11, 12]],
                [[58, 64], [139, 154]]
            ),
            # 1x1 * 1x1 = 1x1
            (
                [[5]],
                [[3]],
                [[15]]
            ),
            # 2x2 * 2x2 = 2x2
            (
                [[1, 2], [3, 4]],
                [[5, 6], [7, 8]],
                [[19, 22], [43, 50]]
            ),
            # 3x1 * 1x3 = 3x3
            (
                [[1], [2], [3]],
                [[4, 5, 6]],
                [[4, 5, 6], [8, 10, 12], [12, 15, 18]]
            ),
            # 1x3 * 3x1 = 1x1
            (
                [[1, 2, 3]],
                [[4], [5], [6]],
                [[32]]
            )
        ]
        
        try:
            for matrix1, matrix2, expected in test_cases:
                result = student.matrix_multiply(matrix1, matrix2)
                self.assertEqual(result, expected, f"matrix_multiply({matrix1}, {matrix2}) returned {result}, expected {expected}")
            
            score += 1
            feedback_messages.append("✅ matrix_multiply function works correctly for all test cases")
        except AssertionError as e:
            feedback_messages.append(f"❌ matrix_multiply() doesn't produce the expected result. Remember: result[i][j] = sum of matrix1[i][k] * matrix2[k][j] for all k.")
            raise
        except Exception as e:
            feedback_messages.append(f"⚠️ matrix_multiply() raised an error: {type(e).__name__}. Check your nested loop logic and matrix indexing.")
            raise

    def test_is_palindrome_iterative(self):
        global score
        if not hasattr(student, 'is_palindrome_iterative') or not callable(getattr(student, 'is_palindrome_iterative', None)):
            feedback_messages.append("🤔 Could not find a function named 'is_palindrome_iterative'. Make sure you've implemented this function in consolidation.py.")
            self.fail("Missing or invalid 'is_palindrome_iterative' function.")
            return

        # Test cases
        test_cases = [
            ("civic", True),
            ("Civic", True),  # Case insensitive
            ("madam", True),
            ("madAm", True),  # Case insensitive
            ("racecar", True),
            ("hello", False),
            ("world", False),
            ("A", True),      # Single character
            ("", True),       # Empty string (considered palindrome)
            ("Aa", True),     # Two identical characters (case insensitive)
            ("Ab", False),    # Two different characters
            ("A man a plan a canal Panama", True),  # With spaces and punctuation
            ("race a car", False),  # With spaces (not palindrome)
            ("Was it a car or a cat I saw", True),  # Complex case
            ("12321", True),  # Numbers
            ("12345", False)  # Numbers (not palindrome)
        ]
        
        try:
            for word, expected in test_cases:
                result = student.is_palindrome_iterative(word)
                self.assertEqual(result, expected, f"is_palindrome_iterative('{word}') returned {result}, expected {expected}")
            
            score += 1
            feedback_messages.append("✅ is_palindrome_iterative function works correctly for all test cases")
        except AssertionError as e:
            feedback_messages.append(f"❌ is_palindrome_iterative() doesn't handle all cases correctly. Remember: ignore case, spaces, and punctuation. Compare characters iteratively.")
            raise
        except Exception as e:
            feedback_messages.append(f"⚠️ is_palindrome_iterative() raised an error: {type(e).__name__}. Check your string processing and comparison logic.")
            raise

def run_tests():
    # Display header
    color_print("🚀 Running hidden tests...", Colors.CYAN, True)
    
    # Run tests
    suite = unittest.TestLoader().loadTestsFromTestCase(TestConsolidation)
    runner = unittest.TextTestRunner(verbosity=0, stream=io.StringIO())
    runner.run(suite)
    
    # Calculate percentage for the final score
    percentage = (score / total) * 100 if total > 0 else 0
    
    # Determine color based on score
    if percentage >= 80:
        result_color = Colors.GREEN
    elif percentage >= 60:
        result_color = Colors.YELLOW
    else:
        result_color = Colors.RED
        
    # Display results
    print("\n" + "=" * 50)
    color_print("       ASSESSMENT RESULTS       ", Colors.CYAN, True)
    print("=" * 50 + "\n")

    print("📋 Feedback:")
    for msg in feedback_messages:
        if "✅" in msg:
            color_print(msg, Colors.GREEN)
        else:
            color_print(msg, Colors.RED)

    print("\n" + "-" * 50)
    color_print(f"🏁 Final Score: {score}/{total} ({percentage:.1f}%)", result_color, True)
    
    if score == total:
        color_print("🎉 Excellent work! You've completed all the requirements for this assessment.", Colors.GREEN)
    elif score >= 5:
        color_print("👍 You're making good progress. Review the feedback above to complete the remaining requirements.", Colors.YELLOW)
    else:
        color_print("🛠️ You have several requirements to address. Focus on implementing the missing functions.", Colors.RED)
    print("-" * 50)

if __name__ == '__main__':
    run_tests()